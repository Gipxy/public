package com.hackerrank.restcontrolleradvice.advice;


import com.hackerrank.restcontrolleradvice.dto.BuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzBuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzException;
import com.hackerrank.restcontrolleradvice.dto.GlobalError;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerAdvice extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = FizzException.class)
    protected ResponseEntity<Object> handleFizz(
            RuntimeException ex, WebRequest request) {
        FizzException fex = (FizzException) ex;
        GlobalError errorResp = new GlobalError(fex.getMessage(), fex.getErrorReason());
        return handleExceptionInternal(ex, errorResp,
                new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    @ExceptionHandler(value = BuzzException.class)
    protected ResponseEntity<Object> handleBuzz(
            RuntimeException ex, WebRequest request) {
        BuzzException fex = (BuzzException) ex;
        GlobalError errorResp = new GlobalError(fex.getMessage(), fex.getErrorReason());
        return handleExceptionInternal(ex, errorResp,
                new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(value = FizzBuzzException.class)
    protected ResponseEntity<Object> handleFizzBuzz(
            RuntimeException ex, WebRequest request) {
        FizzBuzzException fex = (FizzBuzzException) ex;
        GlobalError errorResp = new GlobalError(fex.getMessage(), fex.getErrorReason());
        return handleExceptionInternal(ex, errorResp,
                new HttpHeaders(), HttpStatus.INSUFFICIENT_STORAGE, request);
    }
}
