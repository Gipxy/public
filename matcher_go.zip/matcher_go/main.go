package main

import (
	"fmt"
	"context"
	"github.com/aws/aws-lambda-go/lambda"
	"math/rand"
	"time"
)

type MyEvent struct {
	Name string `json:"name"`
	N int `json:"n"`
}

func HandleRequest(ctx context.Context, name MyEvent) (string, error) {

	testMatching(name.N)

	return fmt.Sprintf("Hello %s!", name.Name ), nil
}

func main() {
	lambda.Start(HandleRequest)
}


type Order struct {
	baseCcy  string
	termCcy  string
	direction  string
	tier int
	targetRate float64
	status   int
	timeExpiry   int64
}

type Rate struct {
	baseCcy  string
	termCcy  string
	tier int
	rate float64
}

func makeTimestamp() int64 {
	return time.Now().UnixNano() / int64(time.Millisecond)
}

func genOrders(n int) []Order{
	buySell := [...]string{"b", "s"}
	s1 := rand.NewSource(time.Now().UnixNano())
	r1 := rand.New(s1)

	orders := make([]Order, n)
	currentTime := makeTimestamp() + 3 * 60*60*24
	for i := 0; i < n; i++ {
		orders[i] = Order{"USD","SGD", buySell[r1.Intn(2)], r1.Intn(2), r1.Float64(),r1.Intn(6),currentTime}
	}
	return orders
}

func matching(rate Rate, order Order) bool {
	if order.status == 5 {
		return false
	}
	if order.timeExpiry < makeTimestamp() {
		return false
	}
	if order.tier != rate.tier {
		return false
	}
	if order.direction == "b" && order.targetRate < rate.rate {
		return false
	}
	if order.direction == "s" && order.targetRate > rate.rate {
		return false
	}
	return true
}

func testOne(rndOrders []Order) {
	s1 := rand.NewSource(time.Now().UnixNano())
	r1 := rand.New(s1)

	z1 := makeTimestamp()
	rate := Rate{"USD","SGD", 1,r1.Float64()}
	countMatch := 0
	for i := 0; i < len(rndOrders); i++ {
		if matching(rate, rndOrders[i]) {
			countMatch = countMatch + 1
		}
	}

	z2 := makeTimestamp()
	fmt.Println("Matching time:", z2-z1, "Number of match: ", countMatch)
}

func testMatching(n int) {
	// data perparation
	t1 := makeTimestamp()
	rndOrders := genOrders(n)
	t2 := makeTimestamp()
	fmt.Println("----- Gen time: ", t2-t1)
	fmt.Println("Number of orders: ", len(rndOrders))
	//perform matching
	t1 = makeTimestamp()
	for i := 0; i < 3; i++ {
		testOne(rndOrders)
	}
	t2 = makeTimestamp()
	fmt.Println("----- Total matching time:", t2-t1)
}
